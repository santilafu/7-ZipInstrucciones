DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u004f"] = [
	{ "s": "O", "p": [14, 12, 11, 6, 5, 3] },
	{ "s": "OCUPAN", "p": [3] },
	{ "s": "OLVIDE", "p": [4] },
	{ "s": "OPCIONES", "p": [14] },
	{ "s": "OPERACIONES", "p": [11] },
	{ "s": "OPERACIÓN", "p": [11] },
	{ "s": "ORDENADOR", "p": [14] },
	{ "s": "ORGANIZAR", "p": [11] },
	{ "s": "ORIGINAL", "p": [11] }
];