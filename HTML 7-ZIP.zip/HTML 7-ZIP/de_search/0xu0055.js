DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0055"] = [
	{ "s": "UN", "p": [14, 13, 3, 2] },
	{ "s": "UNA", "p": [4] },
	{ "s": "UNO", "p": [11, 3] },
	{ "s": "USANDO", "p": [3] },
	{ "s": "USES", "p": [14] },
	{ "s": "USUARIO", "p": [14, 2] },
	{ "s": "UTILIZAR", "p": [11] }
];