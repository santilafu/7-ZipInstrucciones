DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u004c"] = [
	{ "s": "LA", "p": [14, 12, 11, 13, 6, 5, 4, 2] },
	{ "s": "LAS", "p": [14, 11, 2] },
	{ "s": "LISTA", "p": [14, 5] },
	{ "s": "LLENAR", "p": [14] },
	{ "s": "LOCALIZA", "p": [13] },
	{ "s": "LOCALIZAR", "p": [12] },
	{ "s": "LOS", "p": [13, 12, 2] }
];