DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u004e"] = [
	{ "s": "NAVEGA", "p": [12] },
	{ "s": "NECESARIOS", "p": [2] },
	{ "s": "NECESITAS", "p": [2] },
	{ "s": "NO", "p": [14, 4] }
];