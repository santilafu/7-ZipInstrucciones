DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0032"] = [
	{ "s": "2", "p": [13, 10, 8, 11, 12, 9, 7, 6, 5, 4, 14] },
	{ "s": "2.1", "p": [12] },
	{ "s": "2.2", "p": [13] },
	{ "s": "2026", "p": [1] }
];