DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0037"] = [
	{ "s": "7", "p": [3, 14, 5, 11, 2, 1] },
	{ "s": "7-ZIP", "p": [3, 14, 5, 11, 2, 1] },
	{ "s": "7Z", "p": [13, 12, 3] }
];