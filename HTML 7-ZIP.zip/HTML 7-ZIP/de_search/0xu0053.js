DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0053"] = [
	{ "s": "SE", "p": [14, 11] },
	{ "s": "SECCIÓN", "p": [14, 11] },
	{ "s": "SELECCIONA", "p": [11] },
	{ "s": "SELECCIONAR", "p": [8] },
	{ "s": "SELECCIÓNALO", "p": [13] },
	{ "s": "SELECCIÓNALOS", "p": [12] },
	{ "s": "SI", "p": [2, 14, 13] },
	{ "s": "SIDO", "p": [2] },
	{ "s": "SIGNO", "p": [13, 12] },
	{ "s": "SISTEMA", "p": [14] },
	{ "s": "SOBRE", "p": [14] },
	{ "s": "SOLO", "p": [14, 11, 3, 2] },
	{ "s": "SPANISH", "p": [14] },
	{ "s": "SU", "p": [11, 3, 14] },
	{ "s": "SUPERIOR", "p": [14, 5] }
];