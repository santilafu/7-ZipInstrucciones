DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0051"] = [
	{ "s": "QUE", "p": [14, 11, 12, 3] },
	{ "s": "QUIERES", "p": [14, 12, 2] },
	{ "s": "QUÉ", "p": [3, 14, 2] }
];