DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0052"] = [
	{ "s": "RAR", "p": [14, 13, 11] },
	{ "s": "RATÓN", "p": [12] },
	{ "s": "REALIZAR", "p": [11] },
	{ "s": "RECOMENDAMOS", "p": [12] },
	{ "s": "REDUCIR", "p": [11, 3] },
	{ "s": "RUTA", "p": [5] }
];