DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0048"] = [
	{ "s": "HA", "p": [2] },
	{ "s": "HABITUALMENTE", "p": [14] },
	{ "s": "HACES", "p": [14] },
	{ "s": "HAGAS", "p": [14] },
	{ "s": "HASTA", "p": [12] },
	{ "s": "HERRAMIENTAS", "p": [10, 14, 6, 5] }
];