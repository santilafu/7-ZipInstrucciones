DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex.ids = {
	"1": ["Página p... Se requiere licencia de pago.", "index.htm", []],
	"2": ["1. INTR... Se requiere licencia de pago.", "introduccion.htm", []],
	"3": ["1.1. ¿Qué... Se requiere licencia de pago.", "_que_es_7_zip_.htm", [1]],
	"4": ["1.2. Interf... Se requiere licencia de pago.", "interfaz_principal.htm", [1]],
	"5": ["1.2.1. Ven... Se requiere licencia de pago.", "ventana_7_zip.htm", [1,5]],
	"6": ["1.2.1.1. Barra de... Se requiere licencia de pago.", "barra_de_menus_aplicacion.htm", [1,5,8]],
	"7": ["1.2.1.1.1... Se requiere licencia de pago.", "archivo.htm", [1,5,8,9]],
	"8": ["1.2.1.1.... Se requiere licencia de pago.", "editar.htm", [1,5,8,9]],
	"9": ["1.2.1.1.3.... Se requiere licencia de pago.", "favoritos.htm", [1,5,8,9]],
	"10": ["1.2.1.2. Barra ... Se requiere licencia de pago.", "barra_de_herramientas_.htm", [1,5,8]],
	"11": ["2. OPERACIO... Se requiere licencia de pago.", "operaciones_basicas.htm", []],
	"12": ["2.1. Cómo Comp... Se requiere licencia de pago.", "como_comprimir_archivos.htm", [2]],
	"13": ["2.2. Cómo Desco... Se requiere licencia de pago.", "como_descomprimir_archivos.htm", [2]],
	"14": ["3. CONFI... Se requiere licencia de pago.", "3__configuracion.htm", []]
};