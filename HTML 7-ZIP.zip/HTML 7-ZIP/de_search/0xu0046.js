DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0046"] = [
	{ "s": "FAVORITOS", "p": [9, 6] },
	{ "s": "FILE", "p": [1] },
	{ "s": "FORMATO", "p": [12, 3] },
	{ "s": "FUNCIONAMIENTO", "p": [14] },
	{ "s": "FUNCIONES", "p": [2] },
	{ "s": "FUNCIÓN", "p": [3] },
	{ "s": "FUNDAMENTALES", "p": [11] },
	{ "s": "FÁCILMENTE", "p": [3] }
];