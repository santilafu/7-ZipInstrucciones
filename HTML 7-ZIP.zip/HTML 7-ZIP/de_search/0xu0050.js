DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0050"] = [
	{ "s": "PALABRA", "p": [4] },
	{ "s": "PANEL", "p": [14, 5] },
	{ "s": "PARA", "p": [11, 14, 12, 2, 6, 5, 4, 3] },
	{ "s": "PASO", "p": [11, 2] },
	{ "s": "PASOS", "p": [2] },
	{ "s": "PENDIENTES", "p": [4] },
	{ "s": "PERMITE", "p": [14] },
	{ "s": "PERSONALIZACIÓN", "p": [14, 2] },
	{ "s": "PESTAÑA", "p": [14] },
	{ "s": "PESTAÑAS", "p": [14] },
	{ "s": "POR", "p": [12, 11, 3] },
	{ "s": "PREFERENCIAS", "p": [14] },
	{ "s": "PREFERIDO", "p": [14] },
	{ "s": "PRINCIPAL", "p": [4, 1, 3] },
	{ "s": "PRINCIPALES", "p": [11, 2] },
	{ "s": "PROBAR", "p": [10] },
	{ "s": "PROGRAMA", "p": [11] },
	{ "s": "PROPIO", "p": [3] },
	{ "s": "PUEDES", "p": [14] },
	{ "s": "PULSA", "p": [13, 12, 14] },
	{ "s": "PULSANDO", "p": [13] },
	{ "s": "PULSAR", "p": [14] },
	{ "s": "PUNTOS", "p": [13] },
	{ "s": "PÁGINA", "p": [1] }
];