DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u004d"] = [
	{ "s": "MANAGER", "p": [1] },
	{ "s": "MANIPULAR", "p": [6, 5] },
	{ "s": "MANTÉN", "p": [14] },
	{ "s": "MANUAL", "p": [2, 1] },
	{ "s": "MARCADAS", "p": [14] },
	{ "s": "MEJOR", "p": [11] },
	{ "s": "MENOS", "p": [13] },
	{ "s": "MENÚ", "p": [14, 11] },
	{ "s": "MENÚS", "p": [6, 5] },
	{ "s": "MOVER", "p": [10] },
	{ "s": "MUY", "p": [14] },
	{ "s": "MÁS", "p": [14, 12] },
	{ "s": "MÁXIMA", "p": [12] }
];