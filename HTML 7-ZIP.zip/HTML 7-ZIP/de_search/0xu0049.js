DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0049"] = [
	{ "s": "ICONO", "p": [13, 12] },
	{ "s": "IDEAL", "p": [11] },
	{ "s": "IDIOMA", "p": [14] },
	{ "s": "IMPORTANTES", "p": [14] },
	{ "s": "INFORMACIÓN", "p": [11, 10] },
	{ "s": "INSTANTÁNEO", "p": [14] },
	{ "s": "INSTRUCCIONES", "p": [2, 1] },
	{ "s": "INTERACTIVO", "p": [2] },
	{ "s": "INTERFAZ", "p": [4, 14, 12, 2] },
	{ "s": "INTERNET", "p": [11] },
	{ "s": "INTRODUCCION", "p": [2] },
	{ "s": "IZQUIERDA", "p": [11] }
];