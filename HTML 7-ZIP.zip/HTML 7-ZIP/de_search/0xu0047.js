DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0047"] = [
	{ "s": "GESTIÓN", "p": [11] },
	{ "s": "GESTOR", "p": [3] },
	{ "s": "GUARDAR", "p": [12] },
	{ "s": "GUÍAS", "p": [11, 2] }
];