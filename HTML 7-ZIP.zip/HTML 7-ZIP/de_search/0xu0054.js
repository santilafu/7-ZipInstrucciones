DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0054"] = [
	{ "s": "TAMAÑO", "p": [11] },
	{ "s": "TANTO", "p": [2] },
	{ "s": "TAREAS", "p": [11, 4] },
	{ "s": "TASA", "p": [3] },
	{ "s": "TE", "p": [11, 14] },
	{ "s": "TEMA", "p": [4] },
	{ "s": "TERMINADO", "p": [13] },
	{ "s": "TODO", "p": [14, 8] },
	{ "s": "TRES", "p": [13] },
	{ "s": "TU", "p": [14, 11, 2] },
	{ "s": "TUS", "p": [14, 3] }
];