DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0042"] = [
	{ "s": "BARRA", "p": [10, 6, 5] },
	{ "s": "BIENVENIDO", "p": [2] },
	{ "s": "BORRAR", "p": [10] },
	{ "s": "BOTÓN", "p": [10, 14, 13, 12, 5] },
	{ "s": "BUSCA", "p": [14] },
	{ "s": "BÁSICAS", "p": [11, 2] }
];