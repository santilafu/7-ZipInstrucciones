DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u005a"] = [
	{ "s": "ZIP", "p": [14, 3, 11, 5, 2, 13, 12, 1] }
];