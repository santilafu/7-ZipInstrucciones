DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0044"] = [
	{ "s": "DE", "p": [5, 2, 11, 10, 6, 3, 14, 13, 12, 1] },
	{ "s": "DECIRLE", "p": [14] },
	{ "s": "DEL", "p": [13, 12] },
	{ "s": "DERECHO", "p": [14] },
	{ "s": "DESCARGAS", "p": [11] },
	{ "s": "DESCOMPRIMIR", "p": [13, 11, 2] },
	{ "s": "DESCRIPCIÓN", "p": [4, 2] },
	{ "s": "DESEAS", "p": [13, 11] },
	{ "s": "DESEES", "p": [14] },
	{ "s": "DESTACA", "p": [3] },
	{ "s": "DESTINO", "p": [13] },
	{ "s": "DETALLADO", "p": [11] },
	{ "s": "DETALLAMOS", "p": [14] },
	{ "s": "DIRECTAMENTE", "p": [14] },
	{ "s": "DIRÍGETE", "p": [14] },
	{ "s": "DISCO", "p": [2] },
	{ "s": "DISEÑADO", "p": [2] },
	{ "s": "DOBLE", "p": [14] },
	{ "s": "DOCUMENTO", "p": [6, 5, 2] },
	{ "s": "DOCUMENTOS", "p": [11, 3, 2] },
	{ "s": "DOMINAR", "p": [2] },
	{ "s": "DOS", "p": [11] }
];