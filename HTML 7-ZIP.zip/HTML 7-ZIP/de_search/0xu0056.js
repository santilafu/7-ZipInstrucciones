DR_EXPLAIN = DR_EXPLAIN || {};
DR_EXPLAIN.searchIndex = DR_EXPLAIN.searchIndex || {};
DR_EXPLAIN.searchIndex["\u0056"] = [
	{ "s": "VARIOS", "p": [11, 3, 2] },
	{ "s": "VENTANA", "p": [5, 12] },
	{ "s": "VER", "p": [11, 6] },
	{ "s": "VERDE", "p": [12] },
	{ "s": "VISTA", "p": [6, 5] },
	{ "s": "VISUAL", "p": [2] }
];